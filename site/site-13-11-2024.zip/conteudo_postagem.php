<div id="conteudo_principal">
	<h1 class="titulos"> POSTAGENS  </h1>
	<div class="postagens">
		<h1 class="titulos"> </h1>
		<img src="imagens/postagem.jpg" class="imagem">
		<p class="paragrafo">Paragrafo</p>
		<span class="data">10/03/2018</span> 
	</div>

	<!--<div class="postagens">
		<h1 class="titulos"> TITULOS DA POSTAGEM </h1>
		<img src="imagens/postagem.jpg" class="imagem">
		<p class="paragrafo">Paragrafo</p>
		<span class="data">10/03/2018</span> 
	</div>
	-->


</div>

<div id="recentes">
	<h1 class="titulos">Recentes</h1>
	<div class="postagens_recentes">
		<h1 class="titulos"><a href="#">   Titulo dos arquivos recentes</a></h1> 
		<span class="data"> 11/03/2018</span>
	</div>






</div>