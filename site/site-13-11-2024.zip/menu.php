<ul class="link_menu">
	<li><a href="index.php">HOME</a><li>
	<li><a href="postagem.php">POSTAGENS</a></li>
	<li><a href="script_css.php">SCRIPT</a></li>
	<li><a href="contato.php">CONTATO</a></li>
</ul>