<?php

unset($_SESSION);

header('location:sindex.php');


?>